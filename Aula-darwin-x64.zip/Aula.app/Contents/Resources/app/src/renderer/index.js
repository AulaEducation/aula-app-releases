const {app} = require('electron').remote;

// Tell the webapp that we are running inside electron
window.isElectron = true;
window.electron = {
	version:app.getVersion()
}

// Online/Offline detection and overlay
require('./online-offline.js');

// Notifications
require('./notifications.js');