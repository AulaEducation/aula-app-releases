/**
 * Adds overlay divs to the begining off the page
 * toggles their visibility when internet is on/off
 */

window.addEventListener('load', (e) => {
  addOverlayToBody(window)
});

window.addEventListener('online', (e) => {
  window.document.getElementById('electron-overlay').style.display = 'none';
});

window.addEventListener('offline', (event, arg) => {
  window.document.getElementById('electron-overlay').style.display = 'flex';
});

function addOverlayToBody(window) {
  // Add overlay elements to DOM
  const overlayHtml = '<div id="electron-overlay"><div id="electron-overlay-text">No Internet connection</div></div>';
  window.document.body.insertAdjacentHTML('afterbegin', overlayHtml);

  // Style elements
  const overlay = window.document.getElementById('electron-overlay')
  overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
  overlay.style.display = 'none';
  overlay.style.position = 'absolute';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.zIndex = '99999';
  overlay.style.left = 0;
  overlay.style.top = 0;
  overlay.style.justifyContent = 'center';

  const overlayText = window.document.getElementById('electron-overlay-text')
  overlayText.style.color = '#FFF';
  overlayText.style.fontFamily = 'Courier new';
  overlayText.style.alignSelf = 'center';
  overlayText.style.backgroundColor = 'rgba(0,0,0,0.5)';
  overlayText.style.padding = '15px';
}