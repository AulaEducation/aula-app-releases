const { ipcRenderer } = require('electron');

class NotificationProcessor {
  constructor() {
    this.unreadNotificationsCount = 0;
  }

  didReceiveState(state) {
    if (state.data.classRooms) {
      const unreadNotificationsCount = Object.keys(state.data.classRooms).map((key) => {
        const unread = state.data.classRooms[key].unread;
        return Object.keys(unread).map((unreadKey) => (
          unread[unreadKey].length
        )).reduce((sum, i) => (sum + i), 0);
      }).reduce((sum, i) => (sum + i), 0);

      if (this.unreadNotificationsCount !== unreadNotificationsCount) {
        console.log('sending count to main '+unreadNotificationsCount);
        ipcRenderer.send('update-unread-notifications-count', unreadNotificationsCount);
      }

      this.unreadNotificationsCount = unreadNotificationsCount;
    }
  }
}

const notificationProcessor = new NotificationProcessor();

window.onStateUpdate = (state,action) => {
  notificationProcessor.didReceiveState(state);
};