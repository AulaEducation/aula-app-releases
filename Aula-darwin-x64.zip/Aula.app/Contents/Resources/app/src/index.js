import {app, BrowserWindow, Menu, ipcMain, screen, session, shell} from 'electron'
import path from 'path'
import url from 'url'
import ublendMenu from './menu.template'
import cfg from './conf'
import enableAutoUpdate from './autoupdater'
// Set Desktop Shortcuts and icons on install
if(require('electron-squirrel-startup')) app.quit();

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let win

function createWindow() {

  const {width, height} = screen.getPrimaryDisplay().workAreaSize

  // Create the browser window.
  win = new BrowserWindow({
    width: width < 1450 ? width -50 : 1450,
    height: height < 750 ? height - 50 : 750,
    minWidth: 1150,
    minHeight: 650,
    backgroundColor: '#8543c0',
    //titleBarStyle: 'hidden-inset',
    webPreferences: {
      preload: path.join(__dirname, 'renderer/index.js')
    }
  })
  win.loadURL(cfg.loadUrl)

  cfg.devTools ? win.webContents.openDevTools() : null;

  // Clear windows
  win.on('closed', () => {
    win = null
  })

  // Add Menu
  const menu = Menu.buildFromTemplate(ublendMenu.template)
  Menu.setApplicationMenu(menu)

  // Auto Update
  cfg.updateEnabled ? enableAutoUpdate() : null;

  // Catch opening new windows and detect if url is not internal
  // Open default browser
  win.webContents.on('new-window', (event, url) => {
    if(url.indexOf('ublend.co') === -1){
      event.preventDefault();
      shell.openExternal(url)
    }
  })
}

app.on('ready', createWindow)

app.on('window-all-closed', () => {
  // On macOS it is common for applications and their menu bar to stay active
  // until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  // On macOS it's common to re-create a window in the app when the dock icon is
  // clicked and there are no other windows open.
  if (win === null) {
    createWindow()
  }
})

// Receive notifications and set setBadge
ipcMain.on('update-unread-notifications-count', (event, count) => {
  app.dock.setBadge(count > 0 ? '•' : '');
  app.dock.bounce();
});