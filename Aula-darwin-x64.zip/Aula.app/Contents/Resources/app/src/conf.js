import {app} from 'electron'
import os from 'os'


export default {
  loadUrl: 'https://app.aula.education/',
  //loadUrl: 'http://localhost:8080/',
  // updaterUrl: 'https://hazel.general.aula.education/update/'+os.platform() + '_' + os.arch()+'/' + app.getVersion(),
  updaterUrl: `https://hazel.general.aula.education/update/update/${os.platform()}/${app.getVersion()}`,
  updateEnabled: false,
  devTools: false
}

