import {autoUpdater, dialog} from 'electron'
import cfg from './conf'

console.log(cfg.updaterUrl)

export default function enableAutoUpdate(){
	console.log("enableAutoUpdate()")
	autoUpdater.setFeedURL(cfg.updaterUrl)

	autoUpdater.on('error', function (e) {
		console.log("error");
		console.log(e);
	});

	autoUpdater.on('checking-for-update', function () {
		console.log("checking-for-update");
	});

	autoUpdater.on('update-available', function () {
		console.log("update-available");
	});

	autoUpdater.on('update-not-available', function () {
		console.log("update-not-available");
	});

	autoUpdater.on('update-downloaded', function () {
		console.log("update-downloaded");
		dialog.showMessageBox(
            {
                type: 'info',
                buttons: ['Ok'],
                title: 'Update Available',
                message: 'Hey we need to restart app, newer version is available!'
            },()=>{
				autoUpdater.quitAndInstall();
            });
	});

	autoUpdater.checkForUpdates();
}